function isEven(n) {
    return n % 2 == 0;
}

let number = 2
let result = isEven(number)
console.log(result)